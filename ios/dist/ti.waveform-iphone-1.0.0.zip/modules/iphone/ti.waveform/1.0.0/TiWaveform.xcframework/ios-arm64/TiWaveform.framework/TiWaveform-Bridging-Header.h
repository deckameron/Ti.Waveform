//
//  TiWaveform-Bridging-Header.h
//  TiWaveform
//
//  Created by Douglas Alves on 05/02/26.
//

#ifndef TiWaveform_Bridging_Header_h
#define TiWaveform_Bridging_Header_h

#ifdef OPUS_SUPPORT
#import <opus/opus.h>
#endif

#endif /* TiWaveform_Bridging_Header_h */
