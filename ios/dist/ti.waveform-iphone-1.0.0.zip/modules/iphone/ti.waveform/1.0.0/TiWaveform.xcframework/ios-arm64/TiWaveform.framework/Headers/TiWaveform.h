//
//  TiWaveform.h
//  Ti.Waveform
//
//  Created by Your Name
//  Copyright (c) 2026 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiWaveform.
FOUNDATION_EXPORT double TiWaveformVersionNumber;

//! Project version string for TiWaveform.
FOUNDATION_EXPORT const unsigned char TiWaveformVersionString[];

#import <TiWaveform/TiWaveformModuleAssets.h>
